# 🚀 Lumen Browser - Portable Edition

## Quick Start

**Double-click `launch-lumen.bat` to start Lumen Browser!**

---

## System Requirements

- Windows 7/8/10/11
- Google Chrome, Microsoft Edge, or any Chromium browser installed
- No installation needed!

---

## Features

✅ **All TOP 5 Features Included:**
- Vertical Tabs Manager
- Session Manager  
- Smart Bookmarks
- Password Manager
- Universal Sync

✅ **Modern Design:**
- Clean, aesthetic interface
- Smooth animations
- Professional appearance

✅ **Portable:**
- No installation
- Run from USB stick
- Take it anywhere

---

## How It Works

The launcher opens Lumen in Chrome/Edge app mode, giving you a standalone window without browser UI chrome.

---

## Support

Visit: https://github.com/tanvir-talha058/Lumen

---

**Enjoy your browsing!** 🎉
